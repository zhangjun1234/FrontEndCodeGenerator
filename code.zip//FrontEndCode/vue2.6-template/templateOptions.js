export const options = {
  dbchainwallet:
    '["U2FsdGVkX1/YJc7hx4ybsCf+sFfspCl2OHvmosFun6hVzE59VyZuxV/Xvai1M1VqcCUFmPHhSW6pPXWPzuktO1O6xkvwTgZQDRLCI84CPbtJf+u3U3Fe4CW5GpDtn1dU","03c81e37484616dae57b99068f2bdd0c371492c828e0f0dc9640ba69e2074f81b4","cosmos1gs87qsgz3pftzmx2pxfr3hztcuht99twynjkl5"]',
  dbchain_base_url: "http://controlpanel.dbchain.cloud/relay",
  profileName: "15074780072",
  passphrase: "773387501long",
};
