module.exports = {
  devServer: {
    port: 1234,
  },
};
